/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Dark Theme Color System
        'bg-page': '#0A0F19',
        'bg-surface': '#141A25',
        'primary-500': '#00F5FF',
        'secondary-700': '#2C518A',
        'cta-500': '#FF6600',
        'text-primary': '#E4E4E7',
        'text-secondary': '#A0AEC0',
        'border-subtle': '#2D3748',
        'success-500': '#38A169',
        'warning-500': '#DD6B20',
      },
      fontFamily: {
        'heading': ['Satoshi', 'sans-serif'],
        'body': ['Inter', 'sans-serif'],
        'mono': ['JetBrains Mono', 'monospace'],
      },
      fontSize: {
        'hero': '61px',
        'h2': '49px',
        'h3': '39px',
        'h4': '31px',
      },
      spacing: {
        'xs': '8px',
        'sm': '16px',
        'md': '24px',
        'lg': '32px',
        'xl': '48px',
        'xxl': '64px',
        'xxxl': '96px',
      },
      borderRadius: {
        'md': '8px',
        'lg': '12px',
      },
      boxShadow: {
        'glow': '0 0 16px 0 rgba(0, 245, 255, 0.3)',
        'glow-cta': '0 0 24px 0 rgba(255, 102, 0, 0.4)',
      },
      backgroundImage: {
        'hero-gradient': 'radial-gradient(circle at 50% 50%, #1A365D 0%, #0A0F19 70%)',
      },
      animation: {
        'fade-in-up': 'fadeInUp 0.6s ease-out',
        'fade-in': 'fadeIn 0.4s ease-out',
      },
      keyframes: {
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}