'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowRightIcon, PlayIcon } from '@heroicons/react/24/outline'

export default function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-hero-gradient opacity-80" />
      
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary-700/10 rounded-full blur-3xl animate-pulse delay-700" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-cta-500/10 rounded-full blur-2xl animate-pulse delay-300" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 text-center">
        {/* Trust Bar */}
        <div className={`mb-8 transition-all duration-700 ${isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-4'}`}>
          <div className="inline-flex items-center space-x-2 bg-bg-surface/50 backdrop-blur-sm border border-primary-500/20 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-success-500 rounded-full animate-pulse" />
            <span className="text-text-secondary text-sm font-medium">
              Former #2 Nationally Ranked Verizon Director • $12M+ Annual Revenue Impact
            </span>
          </div>
        </div>

        {/* Main Headline */}
        <div className={`transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-6'}`}>
          <h1 className="font-heading font-bold text-hero leading-tight mb-6 max-w-5xl mx-auto">
            Transform Healthcare & Telecom Operations with{' '}
            <span className="bg-gradient-to-r from-primary-500 to-secondary-700 bg-clip-text text-transparent">
              Enterprise AI Automation
            </span>
          </h1>
        </div>

        {/* Subheadline */}
        <div className={`transition-all duration-700 delay-400 ${isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-6'}`}>
          <p className="text-xl text-text-secondary leading-relaxed mb-8 max-w-4xl mx-auto">
            We build custom AI agents, intelligent workflows, and automation systems that deliver measurable ROI – backed by{' '}
            <span className="text-primary-500 font-mono font-semibold">$12M+</span> in proven B2B revenue impact
          </p>
        </div>

        {/* Value Metrics */}
        <div className={`transition-all duration-700 delay-500 ${isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-6'}`}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 max-w-3xl mx-auto">
            <div className="bg-bg-surface/30 backdrop-blur-sm border border-border-subtle rounded-lg p-6">
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">40+</div>
              <div className="text-text-secondary text-sm">Custom AI Agents Built</div>
            </div>
            <div className="bg-bg-surface/30 backdrop-blur-sm border border-border-subtle rounded-lg p-6">
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">5,000+</div>
              <div className="text-text-secondary text-sm">B2B Accounts Served</div>
            </div>
            <div className="bg-bg-surface/30 backdrop-blur-sm border border-border-subtle rounded-lg p-6">
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">35%</div>
              <div className="text-text-secondary text-sm">Administrative Burden Reduced</div>
            </div>
          </div>
        </div>

        {/* CTAs */}
        <div className={`transition-all duration-700 delay-600 ${isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-6'}`}>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              href="#contact"
              className="btn-primary inline-flex items-center space-x-2 text-lg px-8 py-4"
            >
              <span>Schedule Free Assessment</span>
              <ArrowRightIcon className="h-5 w-5" />
            </Link>
            <Link
              href="#tools"
              className="btn-secondary inline-flex items-center space-x-2 text-lg px-8 py-4"
            >
              <PlayIcon className="h-5 w-5" />
              <span>View Our Tools</span>
            </Link>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className={`absolute bottom-8 left-1/2 transform -translate-x-1/2 transition-all duration-700 delay-700 ${isVisible ? 'opacity-100 transform -translate-x-1/2 translate-y-0' : 'opacity-0 transform -translate-x-1/2 translate-y-4'}`}>
          <div className="animate-bounce">
            <svg className="w-6 h-6 text-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </div>
    </section>
  )
}