'use client'

import { 
  ArrowRightIcon,
  PhoneIcon,
  EnvelopeIcon,
  CalendarIcon
} from '@heroicons/react/24/outline'

const contactMethods = [
  {
    icon: CalendarIcon,
    title: "Schedule Consultation",
    description: "Book a free 30-minute strategy call to discuss your AI automation opportunities",
    action: "Schedule Now",
    href: "#contact"
  },
  {
    icon: PhoneIcon,
    title: "Direct Contact",
    description: "Get in touch directly for immediate assistance or urgent inquiries",
    action: "Call Mark",
    href: "tel:+1-555-MAB-AI"
  },
  {
    icon: EnvelopeIcon,
    title: "Email Discussion",
    description: "Send us your project details and we'll respond within 24 hours",
    action: "Send Email",
    href: "mailto:mark@mabaistrategies.com"
  }
]

const nextSteps = [
  {
    step: "01",
    title: "Free Assessment",
    description: "We analyze your current processes and identify AI automation opportunities"
  },
  {
    step: "02", 
    title: "Custom Proposal",
    description: "Receive a detailed proposal with ROI projections and implementation timeline"
  },
  {
    step: "03",
    title: "Rapid Implementation",
    description: "Our proven methodology delivers results in weeks, not months"
  },
  {
    step: "04",
    title: "Ongoing Optimization",
    description: "Continuous improvement and support to maximize your AI investment"
  }
]

export default function CTASection() {
  return (
    <section id="contact" className="py-20 bg-bg-surface">
      <div className="max-w-7xl mx-auto px-6">
        {/* Main CTA Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Ready to Transform Your Operations with AI?
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto">
            Don't let manual processes hold back your business potential. Let's discuss how 
            our proven AI automation solutions can deliver measurable results for your organization.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start mb-16">
          {/* Left Column - Contact Methods */}
          <div>
            <h3 className="font-heading font-semibold text-h4 text-text-primary mb-8">
              Choose Your Preferred Contact Method
            </h3>
            
            <div className="space-y-6">
              {contactMethods.map((method, index) => (
                <div key={index} className="bg-bg-page rounded-lg p-6 border border-border-subtle hover:border-primary-500/30 transition-all duration-200">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center flex-shrink-0">
                      <method.icon className="h-6 w-6 text-primary-500" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-heading font-semibold text-text-primary mb-2">
                        {method.title}
                      </h4>
                      <p className="text-text-secondary text-sm leading-relaxed mb-4">
                        {method.description}
                      </p>
                      <a 
                        href={method.href}
                        className="inline-flex items-center space-x-2 text-primary-500 hover:text-primary-400 font-medium transition-colors duration-200"
                      >
                        <span>{method.action}</span>
                        <ArrowRightIcon className="h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Trust Indicators */}
            <div className="mt-8 bg-gradient-to-r from-primary-500/10 to-secondary-700/10 rounded-lg p-6 border border-primary-500/20">
              <h4 className="font-heading font-semibold text-text-primary mb-4">
                Why Companies Choose MAB AI Strategies
              </h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full" />
                  <span className="text-text-secondary text-sm">Former #2 Nationally Ranked Verizon Director</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full" />
                  <span className="text-text-secondary text-sm">$12M+ proven revenue impact</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full" />
                  <span className="text-text-secondary text-sm">40+ production AI agents deployed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full" />
                  <span className="text-text-secondary text-sm">Industry specialization in Healthcare & Telecom</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Next Steps */}
          <div>
            <h3 className="font-heading font-semibold text-h4 text-text-primary mb-8">
              What Happens Next
            </h3>
            
            <div className="space-y-6">
              {nextSteps.map((step, index) => (
                <div key={index} className="relative">
                  {/* Step Number */}
                  <div className="absolute left-0 top-0 w-12 h-12 rounded-full bg-primary-500 flex items-center justify-center">
                    <span className="text-black font-bold font-mono">{step.step}</span>
                  </div>
                  
                  {/* Step Content */}
                  <div className="ml-16">
                    <h4 className="font-heading font-semibold text-text-primary mb-2">
                      {step.title}
                    </h4>
                    <p className="text-text-secondary text-sm leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                  
                  {/* Connector Line */}
                  {index < nextSteps.length - 1 && (
                    <div className="absolute left-6 top-12 bottom-0 w-px bg-border-subtle" />
                  )}
                </div>
              ))}
            </div>

            {/* ROI Promise */}
            <div className="mt-8 bg-bg-page rounded-lg p-6 border border-border-subtle">
              <h4 className="font-heading font-semibold text-text-primary mb-4">
                Our ROI Promise
              </h4>
              <p className="text-text-secondary text-sm leading-relaxed mb-4">
                Every project comes with clear ROI projections and measurable success metrics. 
                We don't just implement AI – we deliver quantifiable business results.
              </p>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-2xl font-mono font-bold text-primary-500">180%</div>
                  <div className="text-text-secondary text-xs">Average ROI</div>
                </div>
                <div>
                  <div className="text-2xl font-mono font-bold text-primary-500">3-6</div>
                  <div className="text-text-secondary text-xs">Weeks to Results</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-cta-500/20 to-primary-500/20 rounded-lg p-12 border border-cta-500/30">
            <h3 className="font-heading font-bold text-h3 text-text-primary mb-4">
              Don't Let Competitors Get Ahead with AI
            </h3>
            <p className="text-text-secondary text-lg mb-8 max-w-3xl mx-auto">
              Every day you delay AI implementation, your competitors gain ground. 
              The organizations that act now will dominate their industries. The question is: 
              are you ready to lead or follow?
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="#contact"
                className="btn-primary inline-flex items-center space-x-2 text-lg px-8 py-4"
              >
                <CalendarIcon className="h-6 w-6" />
                <span>Schedule Free Strategy Call</span>
                <ArrowRightIcon className="h-5 w-5" />
              </a>
              <a 
                href="#calculator"
                className="btn-secondary inline-flex items-center space-x-2 text-lg px-8 py-4"
              >
                <span>Calculate Your ROI</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}