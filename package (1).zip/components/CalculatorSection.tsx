'use client'

import { useState } from 'react'
import { 
  CalculatorIcon,
  ChartBarIcon,
  CurrencyDollarIcon,
  TrendingUpIcon,
  ArrowTopRightOnSquareIcon
} from '@heroicons/react/24/outline'

export default function CalculatorSection() {
  const [isExpanded, setIsExpanded] = useState(false)

  // Sample calculation data based on the existing calculator
  const sampleCalculations = [
    {
      phase: "Diagnose",
      complexity: "Medium",
      hours: "42 hours",
      cost: "$9,500",
      timeframe: "2-3 weeks",
      impact: "30% efficiency gain"
    },
    {
      phase: "Build",
      complexity: "Standard",
      hours: "120 hours", 
      cost: "$18,000",
      timeframe: "4-6 weeks",
      impact: "40% productivity increase"
    },
    {
      phase: "Scale",
      complexity: "Professional",
      setupCost: "$15,000",
      monthlyCost: "$3,500",
      timeframe: "3-4 weeks",
      impact: "60% ROI in first year"
    }
  ]

  return (
    <section id="calculator" className="py-20 bg-bg-surface">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Interactive ROI Calculator
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto mb-8">
            See exactly what AI automation could mean for your business. Our calculator 
            generates custom proposals based on your specific needs and industry benchmarks.
          </p>
          
          {/* Live Calculator Highlight */}
          <div className="inline-flex items-center space-x-2 bg-success-500/20 border border-success-500/30 rounded-full px-6 py-3">
            <div className="w-3 h-3 bg-success-500 rounded-full animate-pulse" />
            <span className="text-success-500 font-medium">
              Live Calculator: Generate Your Custom Proposal
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left Column - Calculator Overview */}
          <div>
            {/* Live Calculator CTA */}
            <div className="bg-bg-page rounded-lg p-8 border border-border-subtle mb-8">
              <div className="text-center">
                <div className="w-16 h-16 rounded-lg bg-primary-500/20 flex items-center justify-center mx-auto mb-4">
                  <CalculatorIcon className="h-8 w-8 text-primary-500" />
                </div>
                <h3 className="font-heading font-semibold text-h4 text-text-primary mb-4">
                  Try Our Live Business Calculator
                </h3>
                <p className="text-text-secondary mb-6">
                  Get a detailed proposal in minutes. Our calculator considers your specific requirements, 
                  industry, and project complexity to deliver accurate ROI projections.
                </p>
                
                <div className="space-y-4">
                  <a
                    href="https://mab-ai-business-calculator-two.vercel.app/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary w-full inline-flex items-center justify-center space-x-2"
                  >
                    <span>Launch Calculator</span>
                    <ArrowTopRightOnSquareIcon className="h-5 w-5" />
                  </a>
                  
                  <div className="text-text-secondary text-sm">
                    Free to use • No signup required • Instant results
                  </div>
                </div>
              </div>
            </div>

            {/* Calculator Features */}
            <div className="space-y-6">
              <h4 className="font-heading font-semibold text-h4 text-text-primary">
                What the Calculator Provides
              </h4>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <ChartBarIcon className="h-4 w-4 text-primary-500" />
                  </div>
                  <div>
                    <h5 className="font-medium text-text-primary">Custom ROI Projections</h5>
                    <p className="text-text-secondary text-sm">Calculate expected return on investment based on your specific use case and industry benchmarks.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CurrencyDollarIcon className="h-4 w-4 text-primary-500" />
                  </div>
                  <div>
                    <h5 className="font-medium text-text-primary">Detailed Pricing Breakdown</h5>
                    <p className="text-text-secondary text-sm">Transparent pricing for each service phase with no hidden costs or surprises.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <TrendingUpIcon className="h-4 w-4 text-primary-500" />
                  </div>
                  <div>
                    <h5 className="font-medium text-text-primary">Implementation Timeline</h5>
                    <p className="text-text-secondary text-sm">Realistic project timelines and milestone-based delivery schedule.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Sample Calculations */}
          <div>
            <h4 className="font-heading font-semibold text-h4 text-text-primary mb-6">
              Sample Project Calculations
            </h4>
            
            <div className="space-y-4">
              {sampleCalculations.map((calc, index) => (
                <div key={index} className="bg-bg-page rounded-lg p-6 border border-border-subtle hover:border-primary-500/30 transition-all duration-200">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h5 className="font-heading font-semibold text-text-primary">
                        {calc.phase} Phase - {calc.complexity}
                      </h5>
                      <p className="text-text-secondary text-sm">{calc.hours || `${calc.setupCost} setup + ${calc.monthlyCost}/month`}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-mono font-bold text-primary-500">
                        {calc.cost || calc.monthlyCost}
                      </div>
                      <div className="text-text-secondary text-xs">
                        {calc.timeframe}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success-500 rounded-full" />
                    <span className="text-success-500 text-sm font-medium">
                      Expected Impact: {calc.impact}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick ROI Examples */}
            <div className="mt-8 bg-gradient-to-r from-primary-500/10 to-secondary-700/10 rounded-lg p-6 border border-primary-500/20">
              <h5 className="font-heading font-semibold text-text-primary mb-4">
                Typical ROI Examples
              </h5>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">Healthcare Automation</span>
                  <span className="text-success-500 font-mono font-bold">285% ROI</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">Telecom Sales Process</span>
                  <span className="text-success-500 font-mono font-bold">320% ROI</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">Enterprise Workflow</span>
                  <span className="text-success-500 font-mono font-bold">180% ROI</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Calculator Benefits */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center mx-auto mb-4">
              <ChartBarIcon className="h-6 w-6 text-primary-500" />
            </div>
            <h5 className="font-semibold text-text-primary mb-2">Industry Benchmarks</h5>
            <p className="text-text-secondary text-sm">
              Calculations based on real data from 40+ successful AI implementations across healthcare and telecom.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center mx-auto mb-4">
              <CurrencyDollarIcon className="h-6 w-6 text-primary-500" />
            </div>
            <h5 className="font-semibold text-text-primary mb-2">Transparent Pricing</h5>
            <p className="text-text-secondary text-sm">
              No hidden costs or surprises. Our calculator provides detailed breakdowns of all project components.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center mx-auto mb-4">
              <TrendingUpIcon className="h-6 w-6 text-primary-500" />
            </div>
            <h5 className="font-semibold text-text-primary mb-2">Realistic Projections</h5>
            <p className="text-text-secondary text-sm">
              Conservative estimates based on proven results and industry-standard implementation timelines.
            </p>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <div className="bg-bg-page rounded-lg p-8 border border-border-subtle">
            <h3 className="font-heading font-bold text-h3 text-text-primary mb-4">
              Get Your Custom ROI Analysis
            </h3>
            <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
              Use our calculator to see the potential impact for your specific use case, 
              then schedule a consultation to discuss the results with our team.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://mab-ai-business-calculator-two.vercel.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex items-center space-x-2"
              >
                <span>Calculate Your ROI</span>
                <ArrowTopRightOnSquareIcon className="h-5 w-5" />
              </a>
              <a href="#contact" className="btn-secondary">
                Discuss Results
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}