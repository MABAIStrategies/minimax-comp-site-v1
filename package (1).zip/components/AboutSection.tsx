'use client'

import { 
  TrophyIcon,
  BuildingOfficeIcon,
  CodeBracketIcon,
  HeartIcon,
  AcademicCapIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline'

const achievements = [
  {
    title: "D1 Basketball Foundation",
    description: "The discipline, team focus, and performance optimization mindset that drove success in Division 1 basketball now powers our approach to business transformation.",
    icon: TrophyIcon,
    details: [
      "Division 1 competitive environment",
      "Team-first mentality and collaboration",
      "Performance under pressure excellence",
      "Data-driven improvement methodology"
    ]
  },
  {
    title: "Verizon Leadership Success",
    description: "Former #2 nationally ranked Verizon Director with proven track record of delivering exceptional results across enterprise sales organizations.",
    icon: BuildingOfficeIcon,
    details: [
      "#2 National ranking among Sr. Directors",
      "$12M+ annual revenue delivery",
      "Led strategic account portfolio",
      "10 of 12 months at or above quota"
    ]
  },
  {
    title: "Technical Innovation Pioneer",
    description: "While excelling in corporate leadership, built 40+ custom AI agents demonstrating the hustle and technical capability that sets MAB AI Strategies apart.",
    icon: CodeBracketIcon,
    details: [
      "40+ production AI agents built",
      "GPT-4 autonomous agent development",
      "Salesforce and Google Workspace integration",
      "Advanced automation frameworks"
    ]
  },
  {
    title: "Human Connection & Drive",
    description: "As a new father, I bring both personal motivation and relatability to every client engagement, understanding the importance of work-life balance and long-term thinking.",
    icon: HeartIcon,
    details: [
      "New father perspective on priorities",
      "Relatable leadership style",
      "Long-term thinking approach",
      "Personal drive and motivation"
    ]
  }
]

const experience = [
  {
    period: "2023-Present",
    title: "Senior Director, Sales",
    company: "Verizon Business",
    achievements: [
      "Ranked #2 nationally among Sr. Directors with $12M+ team revenue delivery",
      "Reduced administrative burden by 35% through GPT-4 autonomous agents",
      "Elevated two underperforming teams to top national performance in 6 months",
      "Created 'Boot Camp' coaching methodology scaled organization-wide"
    ]
  },
  {
    period: "2021-2023", 
    title: "Director, Enterprise Sales",
    company: "Verizon Business",
    achievements: [
      "Led strategic account portfolio generating $8M+ annual revenue",
      "Developed executive dashboards integrating Salesforce and Google Workspace",
      "Implemented AI-driven prospecting tools increasing pipeline by 45%",
      "Mentored 12 Account Executives to quota achievement"
    ]
  },
  {
    period: "2019-2021",
    title: "Senior Account Executive", 
    company: "Verizon Business",
    achievements: [
      "Consistently achieved 120%+ quota across multiple quarters",
      "Secured 750+ line enterprise account with C-level engagement",
      "Built automated quote generation system reducing turnaround by 60%",
      "Recognized as top performer in Mid-Atlantic region"
    ]
  }
]

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-bg-page">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Meet Your AI Transformation Partner
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto">
            From Division 1 basketball courts to the C-suite of Fortune 500 companies, 
            my journey has been one of relentless pursuit of excellence and innovative problem-solving.
          </p>
        </div>

        {/* Founder Introduction */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          {/* Left Column - Bio */}
          <div>
            <h3 className="font-heading font-bold text-h3 text-text-primary mb-6">
              Mark Bockrath
            </h3>
            <p className="text-text-secondary leading-relaxed mb-6">
              I'm not just another AI consultant – I'm a proven business leader who has delivered 
              <span className="text-primary-500 font-semibold"> $12M+ in annual revenue impact</span> 
              and transformed entire organizations through the power of intelligent automation.
            </p>
            
            <p className="text-text-secondary leading-relaxed mb-6">
              My journey from Division 1 basketball to corporate leadership taught me that success 
              isn't just about individual performance – it's about building systems, empowering teams, 
              and driving measurable results. That's exactly what I bring to AI transformation.
            </p>
            
            <p className="text-text-secondary leading-relaxed mb-8">
              While leading enterprise sales organizations, I didn't just talk about AI – I built 
              <span className="text-primary-500 font-semibold"> 40+ production AI agents</span> 
              that are still operating today, delivering 35% efficiency improvements and proven ROI.
            </p>

            {/* Key Stats */}
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-3xl font-mono font-bold text-primary-500 mb-1">#2</div>
                <div className="text-text-secondary text-sm">National Ranking</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-mono font-bold text-primary-500 mb-1">$12M+</div>
                <div className="text-text-secondary text-sm">Revenue Delivered</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-mono font-bold text-primary-500 mb-1">40+</div>
                <div className="text-text-secondary text-sm">AI Agents Built</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-mono font-bold text-primary-500 mb-1">35%</div>
                <div className="text-text-secondary text-sm">Efficiency Gain</div>
              </div>
            </div>
          </div>

          {/* Right Column - Professional Image Placeholder */}
          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-primary-500/20 to-secondary-700/20 rounded-2xl border border-primary-500/30 flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 rounded-full bg-primary-500/30 flex items-center justify-center mx-auto mb-4">
                  <UserGroupIcon className="h-16 w-16 text-primary-500" />
                </div>
                <p className="text-text-secondary font-medium">Professional Headshot</p>
                <p className="text-text-secondary text-sm">Mark Bockrath, Founder & CEO</p>
              </div>
            </div>
            
            {/* Floating Achievement Badges */}
            <div className="absolute -top-4 -right-4 bg-success-500 rounded-lg px-3 py-2 text-black text-sm font-medium">
              #2 Nationally Ranked
            </div>
            <div className="absolute -bottom-4 -left-4 bg-cta-500 rounded-lg px-3 py-2 text-white text-sm font-medium">
              D1 Basketball
            </div>
          </div>
        </div>

        {/* Core Achievements */}
        <div className="mb-20">
          <h3 className="font-heading font-semibold text-h3 text-center mb-12">
            What Sets Me Apart
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="bg-bg-surface rounded-lg p-8 border border-border-subtle hover:border-primary-500/30 transition-all duration-200">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center flex-shrink-0">
                    <achievement.icon className="h-6 w-6 text-primary-500" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-heading font-semibold text-text-primary mb-3">
                      {achievement.title}
                    </h4>
                    <p className="text-text-secondary leading-relaxed mb-4">
                      {achievement.description}
                    </p>
                    <div className="space-y-2">
                      {achievement.details.map((detail, detailIndex) => (
                        <div key={detailIndex} className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-primary-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-text-secondary text-sm">{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Professional Experience Timeline */}
        <div className="mb-16">
          <h3 className="font-heading font-semibold text-h3 text-center mb-12">
            Professional Experience
          </h3>
          
          <div className="max-w-4xl mx-auto">
            {experience.map((role, index) => (
              <div key={index} className="relative pb-12 last:pb-0">
                {/* Timeline Line */}
                {index < experience.length - 1 && (
                  <div className="absolute left-6 top-16 bottom-0 w-px bg-border-subtle" />
                )}
                
                {/* Timeline Dot */}
                <div className="absolute left-4 top-2 w-4 h-4 rounded-full bg-primary-500 border-4 border-bg-page" />
                
                {/* Content */}
                <div className="ml-16">
                  <div className="bg-bg-surface rounded-lg p-6 border border-border-subtle">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                      <div>
                        <h4 className="font-heading font-semibold text-text-primary text-lg">
                          {role.title}
                        </h4>
                        <p className="text-primary-500 font-medium">{role.company}</p>
                      </div>
                      <div className="text-text-secondary text-sm mt-2 sm:mt-0">
                        {role.period}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      {role.achievements.map((achievement, achIndex) => (
                        <div key={achIndex} className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-success-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-text-secondary text-sm">{achievement}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Personal Touch */}
        <div className="bg-gradient-to-r from-primary-500/10 to-secondary-700/10 rounded-lg p-8 border border-primary-500/20 text-center">
          <HeartIcon className="h-12 w-12 text-primary-500 mx-auto mb-4" />
          <h3 className="font-heading font-bold text-h3 text-text-primary mb-4">
            More Than Just Business
          </h3>
          <p className="text-text-secondary leading-relaxed max-w-3xl mx-auto mb-6">
            As a new father and former athlete, I understand the importance of work-life balance, 
            long-term thinking, and building systems that work for people – not the other way around. 
            This perspective drives my approach to AI implementation: technology should enhance human 
            capability, not replace it.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#contact" className="btn-primary">
              Let's Connect
            </a>
            <a href="#tools" className="btn-secondary">
              See My Work
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}