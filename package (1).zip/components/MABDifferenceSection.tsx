'use client'

import { 
  CodeBracketIcon,
  BuildingOfficeIcon,
  UserIcon,
  RocketLaunchIcon,
  TrophyIcon,
  AcademicCapIcon
} from '@heroicons/react/24/outline'

const differentiators = [
  {
    id: 1,
    title: "Technical Depth",
    subtitle: "Modern Technology Stack",
    description: "We don't just talk about AI – we build with cutting-edge technologies including GPT-4, Python, Salesforce API, Google Workspace, and enterprise-grade automation platforms.",
    icon: CodeBracketIcon,
    details: [
      "GPT-4 powered autonomous agents",
      "Advanced Python and Google Apps Script development", 
      "Salesforce CRM and Google Workspace integration",
      "Enterprise-grade security and scalability"
    ],
    badge: "Proven Tech"
  },
  {
    id: 2,
    title: "Industry Expertise",
    subtitle: "Healthcare & Telecom Specialization",
    description: "Deep understanding of Healthcare and Telecommunications industries with proven success in HIPAA compliance, patient care automation, and telecom infrastructure optimization.",
    icon: BuildingOfficeIcon,
    details: [
      "100% HIPAA compliance in healthcare solutions",
      "Telecom network optimization and customer lifecycle automation",
      "Regulatory compliance and reporting automation",
      "Industry-specific workflow optimization"
    ],
    badge: "Industry Certified"
  },
  {
    id: 3,
    title: "Hands-on Founder Involvement",
    subtitle: "Direct Expert Leadership",
    description: "As founder, I personally lead every project, ensuring direct access to the expertise that delivered $12M+ in revenue impact and 5,000+ account successes.",
    icon: UserIcon,
    details: [
      "Former #2 Nationally Ranked Verizon Director",
      "Personal oversight of every client engagement",
      "Direct access to founder expertise",
      "Relationship-driven service delivery"
    ],
    badge: "Founder-Led"
  },
  {
    id: 4,
    title: "Rapid Deployment Capability",
    subtitle: "Speed Without Compromise",
    description: "Our proven methodology and pre-built frameworks deliver AI solutions 70% faster than industry average, getting you results in weeks, not months.",
    icon: RocketLaunchIcon,
    details: [
      "70% faster deployment than industry standard",
      "Proven implementation frameworks",
      "Pre-built components and templates",
      "Streamlined project management process"
    ],
    badge: "Rapid Results"
  },
  {
    id: 5,
    title: "Performance Mindset",
    subtitle: "D1 Athlete-Driven Excellence",
    description: "The same competitive drive, team focus, and performance optimization mindset that drove success in Division 1 basketball now powers our approach to business transformation.",
    icon: TrophyIcon,
    details: [
      "D1 basketball competitive mindset",
      "Team-focused collaboration approach",
      "Performance optimization expertise",
      "Results-driven methodology"
    ],
    badge: "Performance Driven"
  },
  {
    id: 6,
    title: "Proven Scale",
    subtitle: "Enterprise-Level Experience",
    description: "Experience scaling AI solutions across large organizations with demonstrated success in managing 5,000+ B2B accounts and building 40+ production AI agents.",
    icon: AcademicCapIcon,
    details: [
      "40+ custom AI agents successfully deployed",
      "5,000+ B2B accounts served",
      "$12M+ annual revenue impact delivery",
      "Enterprise-scale implementation experience"
    ],
    badge: "Enterprise Proven"
  }
]

export default function MABDifferenceSection() {
  return (
    <section className="py-20 bg-bg-surface">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            The MAB Difference
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto">
            What sets MAB AI Strategies apart from other AI consulting firms? 
            Six key differentiators that deliver measurable results for your business.
          </p>
        </div>

        {/* Differentiators Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {differentiators.map((item, index) => (
            <div key={item.id} className="card group relative overflow-hidden">
              {/* Badge */}
              <div className="absolute top-4 right-4">
                <span className="bg-primary-500/20 text-primary-500 text-xs px-2 py-1 rounded-full font-medium">
                  {item.badge}
                </span>
              </div>

              {/* Icon */}
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center group-hover:bg-primary-500/30 transition-colors duration-200">
                  <item.icon className="h-6 w-6 text-primary-500" />
                </div>
                <div className="flex-1">
                  <h3 className="font-heading font-semibold text-lg text-text-primary group-hover:text-primary-500 transition-colors duration-200">
                    {item.title}
                  </h3>
                  <p className="text-text-secondary text-sm">{item.subtitle}</p>
                </div>
              </div>

              {/* Description */}
              <p className="text-text-secondary leading-relaxed mb-6">
                {item.description}
              </p>

              {/* Details */}
              <div className="space-y-2">
                {item.details.map((detail, detailIndex) => (
                  <div key={detailIndex} className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-text-secondary text-sm">{detail}</span>
                  </div>
                ))}
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
            </div>
          ))}
        </div>

        {/* Bottom Stats Section */}
        <div className="bg-bg-page rounded-lg p-8 border border-border-subtle">
          <div className="text-center mb-8">
            <h3 className="font-heading font-bold text-h3 text-text-primary mb-2">
              Proven Track Record
            </h3>
            <p className="text-text-secondary">
              Real numbers that demonstrate our commitment to delivering results
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-mono font-bold text-primary-500 mb-2">#2</div>
              <div className="text-text-secondary text-sm mb-1">National Ranking</div>
              <div className="text-text-secondary text-xs">Verizon Sr. Director Leaderboard</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-mono font-bold text-primary-500 mb-2">$12M+</div>
              <div className="text-text-secondary text-sm mb-1">Annual Revenue</div>
              <div className="text-text-secondary text-xs">Delivered through AI optimization</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-mono font-bold text-primary-500 mb-2">35%</div>
              <div className="text-text-secondary text-sm mb-1">Efficiency Gain</div>
              <div className="text-text-secondary text-xs">Administrative burden reduction</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-mono font-bold text-primary-500 mb-2">100%</div>
              <div className="text-text-secondary text-sm mb-1">Success Rate</div>
              <div className="text-text-secondary text-xs">Boot Camp methodology scaling</div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <h3 className="font-heading font-semibold text-h3 mb-4">
            Experience the MAB Difference
          </h3>
          <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
            Ready to work with a team that combines deep technical expertise, industry knowledge, 
            and proven business results?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#contact" className="btn-primary">
              Start Your AI Transformation
            </a>
            <a href="#about" className="btn-secondary">
              Learn About Our Founder
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}