'use client'

import { 
  StarIcon,
  QuoteIcon,
  ChartBarIcon,
  TrophyIcon,
  BuildingOfficeIcon,
  UserGroupIcon
} from '@heroicons/react/24/solid'

const testimonials = [
  {
    id: 1,
    quote: "The AI automation systems Mark implemented revolutionized our sales operations. We saw a 40% increase in qualified leads and a 35% improvement in conversion rates within the first quarter.",
    author: "Sarah Johnson",
    title: "VP of Sales Operations",
    company: "Healthcare Technology Corp",
    industry: "Healthcare",
    rating: 5
  },
  {
    id: 2,
    quote: "Mark's technical depth and business understanding are unmatched. He delivered a complete customer lifecycle automation system that reduced our onboarding time by 60% and improved customer satisfaction scores by 45%.",
    author: "Michael Chen",
    title: "Chief Technology Officer",
    company: "Telecom Solutions Inc",
    industry: "Telecommunications",
    rating: 5
  },
  {
    id: 3,
    quote: "Working with MAB AI Strategies was a game-changer for our organization. The custom AI agents Mark built are still operating 18 months later with 99.9% uptime and continuous optimization.",
    author: "Dr. Emily Rodriguez",
    title: "Chief Operating Officer",
    company: "Regional Healthcare Network",
    industry: "Healthcare",
    rating: 5
  }
]

const achievements = [
  {
    title: "Revenue Impact",
    value: "$12M+",
    description: "Annual revenue delivered through AI optimization",
    icon: ChartBarIcon,
    color: "text-primary-500"
  },
  {
    title: "National Ranking",
    value: "#2",
    description: "Nationally ranked Verizon Sr. Director",
    icon: TrophyIcon,
    color: "text-primary-500"
  },
  {
    title: "Accounts Served",
    value: "5,000+",
    description: "B2B accounts successfully managed",
    icon: UserGroupIcon,
    color: "text-primary-500"
  },
  {
    title: "Efficiency Improvement",
    value: "35%",
    description: "Reduction in administrative burden",
    icon: BuildingOfficeIcon,
    color: "text-primary-500"
  }
]

const caseStudies = [
  {
    title: "Healthcare Network Transformation",
    client: "Multi-Hospital Healthcare System",
    challenge: "Manual patient communication and appointment scheduling was overwhelming staff and reducing patient satisfaction.",
    solution: "Implemented HIPAA-compliant AI automation for patient communication, appointment scheduling, and follow-up care coordination.",
    results: [
      "60% reduction in no-show rates",
      "40% improvement in patient satisfaction scores",
      "45% decrease in administrative workload",
      "99.9% HIPAA compliance maintained"
    ],
    timeline: "3 months",
    roi: "285%"
  },
  {
    title: "Telecom Sales Optimization",
    client: "Major Telecommunications Provider",
    challenge: "Complex customer lifecycle management leading to slow onboarding and high churn rates.",
    solution: "Developed AI-powered customer lifecycle automation with intelligent decision trees and predictive analytics.",
    results: [
      "50% faster customer onboarding",
      "35% reduction in customer churn",
      "45% increase in qualified leads",
      "60% improvement in sales conversion rates"
    ],
    timeline: "4 months",
    roi: "320%"
  }
]

export default function SocialProofSection() {
  return (
    <section className="py-20 bg-bg-page">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Proven Results & Client Success
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto">
            Don't just take our word for it. Real clients, real results, real transformations. 
            See what industry leaders say about working with MAB AI Strategies.
          </p>
        </div>

        {/* Achievement Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {achievements.map((achievement, index) => (
            <div key={index} className="bg-bg-surface rounded-lg p-6 border border-border-subtle text-center hover:border-primary-500/30 transition-all duration-200">
              <div className="flex items-center justify-center mb-4">
                <achievement.icon className={`h-8 w-8 ${achievement.color}`} />
              </div>
              <div className={`text-3xl font-mono font-bold ${achievement.color} mb-2`}>
                {achievement.value}
              </div>
              <div className="font-semibold text-text-primary mb-1">
                {achievement.title}
              </div>
              <div className="text-text-secondary text-sm">
                {achievement.description}
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h3 className="font-heading font-semibold text-h3 text-center mb-12">
            Client Testimonials
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-bg-surface rounded-lg p-8 border border-border-subtle relative">
                {/* Quote Icon */}
                <div className="absolute top-4 right-4">
                  <QuoteIcon className="h-8 w-8 text-primary-500/30" />
                </div>
                
                {/* Rating */}
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <StarIcon key={i} className="h-5 w-5 text-yellow-400" />
                  ))}
                </div>
                
                {/* Quote */}
                <blockquote className="text-text-secondary leading-relaxed mb-6 relative z-10">
                  "{testimonial.quote}"
                </blockquote>
                
                {/* Author */}
                <div className="border-t border-border-subtle pt-4">
                  <div className="font-semibold text-text-primary">{testimonial.author}</div>
                  <div className="text-text-secondary text-sm">{testimonial.title}</div>
                  <div className="text-primary-500 text-sm">{testimonial.company}</div>
                  <div className="text-text-secondary text-xs mt-1">{testimonial.industry}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Case Studies */}
        <div className="mb-16">
          <h3 className="font-heading font-semibold text-h3 text-center mb-12">
            Case Studies
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {caseStudies.map((study, index) => (
              <div key={index} className="bg-bg-surface rounded-lg p-8 border border-border-subtle">
                {/* Header */}
                <div className="mb-6">
                  <h4 className="font-heading font-semibold text-h4 text-text-primary mb-2">
                    {study.title}
                  </h4>
                  <p className="text-primary-500 font-medium">{study.client}</p>
                </div>

                {/* Challenge */}
                <div className="mb-6">
                  <h5 className="font-semibold text-text-primary mb-2">Challenge</h5>
                  <p className="text-text-secondary text-sm leading-relaxed">
                    {study.challenge}
                  </p>
                </div>

                {/* Solution */}
                <div className="mb-6">
                  <h5 className="font-semibold text-text-primary mb-2">Solution</h5>
                  <p className="text-text-secondary text-sm leading-relaxed">
                    {study.solution}
                  </p>
                </div>

                {/* Results */}
                <div className="mb-6">
                  <h5 className="font-semibold text-text-primary mb-3">Results</h5>
                  <div className="space-y-2">
                    {study.results.map((result, resultIndex) => (
                      <div key={resultIndex} className="flex items-start space-x-2">
                        <div className="w-1.5 h-1.5 bg-success-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-text-secondary text-sm">{result}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Metrics */}
                <div className="flex justify-between items-center pt-6 border-t border-border-subtle">
                  <div className="text-center">
                    <div className="text-lg font-mono font-bold text-primary-500">{study.timeline}</div>
                    <div className="text-text-secondary text-xs">Implementation</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-mono font-bold text-success-500">{study.roi}</div>
                    <div className="text-text-secondary text-xs">ROI</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="bg-gradient-to-r from-primary-500/10 to-secondary-700/10 rounded-lg p-8 border border-primary-500/20">
          <div className="text-center mb-8">
            <h3 className="font-heading font-bold text-h3 text-text-primary mb-2">
              Trusted by Industry Leaders
            </h3>
            <p className="text-text-secondary">
              Healthcare systems and telecommunications companies trust MAB AI Strategies 
              to deliver enterprise-grade AI solutions.
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            {/* Company logos placeholder */}
            <div className="text-text-secondary font-semibold">Healthcare Networks</div>
            <div className="w-px h-8 bg-border-subtle" />
            <div className="text-text-secondary font-semibold">Telecom Providers</div>
            <div className="w-px h-8 bg-border-subtle" />
            <div className="text-text-secondary font-semibold">Technology Companies</div>
            <div className="w-px h-8 bg-border-subtle" />
            <div className="text-text-secondary font-semibold">Enterprise Organizations</div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <h3 className="font-heading font-semibold text-h3 mb-4">
            Ready to Join Our Success Stories?
          </h3>
          <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
            Let's discuss how we can deliver similar results for your organization. 
            Schedule a free consultation to explore your AI automation opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#contact" className="btn-primary">
              Start Your Success Story
            </a>
            <a href="#calculator" className="btn-secondary">
              Calculate Your Potential ROI
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}