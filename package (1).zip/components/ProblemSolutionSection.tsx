'use client'

import { 
  ArrowTrendingDownIcon, 
  ChartBarIcon, 
  RocketLaunchIcon 
} from '@heroicons/react/24/outline'

const problemsAndSolutions = [
  {
    id: 1,
    problem: "Drowning in repetitive manual tasks?",
    solution: "Intelligent Automation",
    description: "Our AI agents eliminate time-consuming manual processes, freeing your team to focus on strategic initiatives that drive revenue.",
    icon: ArrowTrendingDownIcon,
    metrics: "40+ hours saved per week per team member"
  },
  {
    id: 2,
    problem: "Missing growth opportunities in your data?",
    solution: "AI-Powered Insights",
    description: "Advanced analytics and predictive models uncover hidden patterns, enabling data-driven decisions that maximize ROI.",
    icon: ChartBarIcon,
    metrics: "45% increase in pipeline visibility"
  },
  {
    id: 3,
    problem: "Competitors moving faster with AI?",
    solution: "Rapid Implementation",
    description: "Our proven methodology and pre-built frameworks deliver AI solutions in weeks, not months, giving you the first-mover advantage.",
    icon: RocketLaunchIcon,
    metrics: "70% faster deployment than industry average"
  }
]

export default function ProblemSolutionSection() {
  return (
    <section id="solutions" className="py-20 bg-bg-page">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Stop Losing Ground to Manual Processes
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto">
            Every day you delay AI implementation, your competitors gain ground. Our solutions address the three critical pain points holding back Healthcare & Telecom organizations.
          </p>
        </div>

        {/* Problems & Solutions Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {problemsAndSolutions.map((item, index) => (
            <div key={item.id} className="relative">
              {/* Problem Card */}
              <div className="card h-full">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-lg bg-warning-500/20 flex items-center justify-center">
                      <item.icon className="h-6 w-6 text-warning-500" />
                    </div>
                    <span className="text-text-secondary text-sm font-medium">Problem {index + 1}</span>
                  </div>
                  <div className="w-8 h-px bg-border-subtle" />
                </div>
                
                <h3 className="font-heading font-semibold text-h4 text-text-primary mb-4">
                  {item.problem}
                </h3>
                
                <p className="text-text-secondary leading-relaxed">
                  {item.description}
                </p>
                
                <div className="mt-6 pt-6 border-t border-border-subtle">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success-500 rounded-full" />
                    <span className="text-success-500 text-sm font-medium">Current Impact</span>
                  </div>
                  <p className="text-text-secondary text-sm mt-1">{item.metrics}</p>
                </div>
              </div>

              {/* Solution Arrow & Card */}
              {index < problemsAndSolutions.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <div className="w-8 h-8 rounded-full bg-bg-page border-2 border-primary-500 flex items-center justify-center">
                    <svg className="w-4 h-4 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              )}

              {/* Solution Card */}
              <div className="card mt-6 border-primary-500/20 hover:border-primary-500/40 transition-all duration-300">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center">
                      <item.icon className="h-6 w-6 text-primary-500" />
                    </div>
                    <span className="text-primary-500 text-sm font-medium">Our Solution</span>
                  </div>
                  <div className="w-8 h-px bg-primary-500/50" />
                </div>
                
                <h3 className="font-heading font-semibold text-h4 text-primary-500 mb-4">
                  {item.solution}
                </h3>
                
                <p className="text-text-secondary leading-relaxed mb-6">
                  Powered by {item.id === 1 ? 'our GPT-4 powered autonomous agents' : 
                              item.id === 2 ? 'advanced analytics and machine learning' : 
                              'proven deployment frameworks'} that deliver immediate results.
                </p>
                
                <div className="pt-6 border-t border-primary-500/20">
                  <button className="btn-ghost w-full text-sm">
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center space-x-4">
            <Link 
              href="#tools"
              className="btn-primary"
            >
              See Our AI Tools in Action
            </Link>
            <Link 
              href="#calculator"
              className="btn-secondary"
            >
              Calculate Your ROI
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}