'use client'

import { useState } from 'react'
import { 
  HeartIcon, 
  SignalIcon, 
  ShieldCheckIcon, 
  ChartBarIcon,
  CogIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline'

const industries = [
  {
    id: 1,
    name: "Healthcare",
    subtitle: "HIPAA-Compliant AI Solutions",
    description: "Transform patient care, operational efficiency, and data security with enterprise-grade AI automation specifically designed for healthcare environments.",
    challenges: [
      "HIPAA compliance and data security",
      "Patient communication bottlenecks", 
      "Operational inefficiency across departments",
      "Regulatory reporting requirements"
    ],
    solutions: [
      {
        name: "Patient Communication Automation",
        description: "Intelligent patient engagement systems that schedule appointments, send reminders, and follow up on care plans while maintaining full HIPAA compliance.",
        icon: HeartIcon,
        impact: "40% reduction in no-show rates"
      },
      {
        name: "Operational Efficiency Systems",
        description: "End-to-end workflow optimization for administrative tasks, billing, and resource allocation across healthcare facilities.",
        icon: CogIcon,
        impact: "35% improvement in operational efficiency"
      },
      {
        name: "Regulatory Compliance Monitoring",
        description: "Automated compliance tracking and reporting systems that ensure adherence to healthcare regulations and standards.",
        icon: ShieldCheckIcon,
        impact: "90% reduction in compliance review time"
      },
      {
        name: "Data Analytics & Insights",
        description: "Advanced analytics for patient outcomes, resource utilization, and operational metrics with predictive capabilities.",
        icon: ChartBarIcon,
        impact: "25% improvement in patient outcomes"
      }
    ],
    metrics: [
      { label: "HIPAA Compliance Rate", value: "100%", icon: ShieldCheckIcon },
      { label: "Patient Communication Efficiency", value: "60%", icon: HeartIcon },
      { label: "Operational Cost Reduction", value: "30%", icon: CogIcon },
      { label: "Regulatory Reporting Time", value: "75%", icon: ChartBarIcon }
    ]
  },
  {
    id: 2,
    name: "Telecommunications",
    subtitle: "Customer Lifecycle & Infrastructure Optimization",
    description: "Accelerate customer acquisition, enhance service delivery, and optimize network infrastructure with AI-powered automation and intelligent decision-making systems.",
    challenges: [
      "Complex customer lifecycle management",
      "Network infrastructure optimization",
      "Sales enablement and lead qualification",
      "Service delivery and support efficiency"
    ],
    solutions: [
      {
        name: "Customer Lifecycle Automation",
        description: "Complete automation of customer onboarding, service provisioning, and retention processes with intelligent decision trees.",
        icon: UserGroupIcon,
        impact: "50% faster customer onboarding"
      },
      {
        name: "Network Infrastructure Optimization",
        description: "AI-powered network optimization, predictive maintenance, and resource allocation for maximum performance and uptime.",
        icon: SignalIcon,
        impact: "99.9% network uptime achievement"
      },
      {
        name: "Sales Enablement Platform",
        description: "Intelligent lead qualification, opportunity scoring, and sales process automation that increases conversion rates.",
        icon: ChartBarIcon,
        impact: "45% increase in qualified leads"
      },
      {
        name: "Service Delivery Intelligence",
        description: "Automated service delivery monitoring, issue resolution, and performance optimization across all touchpoints.",
        icon: CogIcon,
        impact: "60% reduction in service tickets"
      }
    ],
    metrics: [
      { label: "Customer Acquisition Rate", value: "45%", icon: UserGroupIcon },
      { label: "Network Performance", value: "99.9%", icon: SignalIcon },
      { label: "Sales Conversion Rate", value: "35%", icon: ChartBarIcon },
      { label: "Service Delivery Time", value: "40%", icon: CogIcon }
    ]
  }
]

export default function IndustryFocusSection() {
  const [activeIndustry, setActiveIndustry] = useState(1)

  const currentIndustry = industries.find(industry => industry.id === activeIndustry)!

  return (
    <section id="industries" className="py-20 bg-bg-page">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Industry-Specific AI Solutions
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto">
            Deep industry expertise combined with proven AI implementation frameworks. 
            We understand the unique challenges in Healthcare and Telecommunications.
          </p>
        </div>

        {/* Industry Toggle */}
        <div className="flex justify-center mb-12">
          <div className="bg-bg-surface rounded-lg p-2 border border-border-subtle">
            <div className="flex space-x-2">
              {industries.map((industry) => (
                <button
                  key={industry.id}
                  onClick={() => setActiveIndustry(industry.id)}
                  className={`px-6 py-3 rounded-md font-medium transition-all duration-200 ${
                    activeIndustry === industry.id
                      ? 'bg-primary-500 text-black'
                      : 'text-text-secondary hover:text-primary-500 hover:bg-primary-500/10'
                  }`}
                >
                  {industry.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Active Industry Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left Column - Overview */}
          <div>
            <div className="mb-8">
              <h3 className="font-heading font-bold text-h3 text-primary-500 mb-2">
                {currentIndustry.subtitle}
              </h3>
              <h4 className="font-heading font-semibold text-h4 text-text-primary mb-4">
                {currentIndustry.name} Solutions
              </h4>
              <p className="text-text-secondary leading-relaxed text-lg">
                {currentIndustry.description}
              </p>
            </div>

            {/* Current Challenges */}
            <div className="mb-8">
              <h5 className="font-heading font-semibold text-lg text-text-primary mb-4">
                Current Industry Challenges
              </h5>
              <div className="space-y-3">
                {currentIndustry.challenges.map((challenge, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-warning-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-text-secondary">{challenge}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Impact Metrics */}
            <div className="bg-bg-surface rounded-lg p-6 border border-border-subtle">
              <h5 className="font-heading font-semibold text-lg text-text-primary mb-4">
                Proven Results
              </h5>
              <div className="grid grid-cols-2 gap-4">
                {currentIndustry.metrics.map((metric, index) => (
                  <div key={index} className="text-center">
                    <div className="flex items-center justify-center mb-2">
                      <metric.icon className="h-6 w-6 text-primary-500" />
                    </div>
                    <div className="text-2xl font-mono font-bold text-primary-500 mb-1">
                      {metric.value}
                    </div>
                    <div className="text-text-secondary text-sm">{metric.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Solutions */}
          <div>
            <h5 className="font-heading font-semibold text-lg text-text-primary mb-6">
              Our AI Solutions
            </h5>
            <div className="space-y-6">
              {currentIndustry.solutions.map((solution, index) => (
                <div key={index} className="bg-bg-surface rounded-lg p-6 border border-border-subtle hover:border-primary-500/30 transition-all duration-200">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center flex-shrink-0">
                      <solution.icon className="h-6 w-6 text-primary-500" />
                    </div>
                    <div className="flex-1">
                      <h6 className="font-heading font-semibold text-text-primary mb-2">
                        {solution.name}
                      </h6>
                      <p className="text-text-secondary text-sm leading-relaxed mb-3">
                        {solution.description}
                      </p>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-success-500 rounded-full" />
                        <span className="text-success-500 text-sm font-medium">
                          Impact: {solution.impact}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary-500/10 to-secondary-700/10 rounded-lg p-8 border border-primary-500/20">
            <h3 className="font-heading font-bold text-h3 text-text-primary mb-4">
              Ready to Transform Your {currentIndustry.name} Operations?
            </h3>
            <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
              Let's discuss how our industry-specific AI solutions can address your unique challenges 
              and deliver measurable results for your organization.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#contact" className="btn-primary">
                Schedule Industry Consultation
              </a>
              <a href="#calculator" className="btn-secondary">
                Calculate {currentIndustry.name} ROI
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}