'use client'

import { useState } from 'react'
import { 
  ChartBarIcon, 
  CogIcon, 
  UserGroupIcon, 
  RocketLaunchIcon,
  PlayCircleIcon,
  ArrowTopRightOnSquareIcon 
} from '@heroicons/react/24/outline'

const featuredTools = [
  {
    id: 1,
    name: "Business Calculator Pro",
    category: "Analytics",
    description: "Interactive ROI calculator for AI automation projects. Generate custom proposals in minutes.",
    features: ["Real-time ROI calculations", "Custom proposal generation", "Industry benchmarking"],
    complexity: "Easy",
    timeEstimate: "5-10 min",
    icon: ChartBarIcon,
    isLive: true,
    demoUrl: "https://mab-ai-business-calculator-two.vercel.app/"
  },
  {
    id: 2,
    name: "Executive Job Search Agent",
    category: "AI Agents",
    description: "Autonomous GPT-4 powered agent that searches, scores, and reports on Director+ opportunities daily.",
    features: ["Daily opportunity scanning", "85% accuracy scoring", "Automatic reporting"],
    complexity: "Moderate",
    timeEstimate: "5-10 min",
    icon: UserGroupIcon,
    isLive: false,
    demoUrl: "#"
  },
  {
    id: 3,
    name: "Sales Intelligence Dashboard",
    category: "Analytics",
    description: "Executive-level dashboard integrating Salesforce CRM with Google Workspace for real-time insights.",
    features: ["Real-time forecasting", "Predictive analytics", "Team performance tracking"],
    complexity: "Advanced",
    timeEstimate: "15-20 min",
    icon: RocketLaunchIcon,
    isLive: false,
    demoUrl: "#"
  },
  {
    id: 4,
    name: "AI Coaching Framework",
    category: "AI Agents",
    description: "Comprehensive coaching framework combining AI-powered analysis with structured development plans.",
    features: ["Performance analysis", "Development planning", "100% success methodology"],
    complexity: "Moderate",
    timeEstimate: "10-15 min",
    icon: CogIcon,
    isLive: false,
    demoUrl: "#"
  },
  {
    id: 5,
    name: "Pipeline Health Monitor",
    category: "Analytics",
    description: "Real-time pipeline analytics with velocity tracking and early warning signals.",
    features: ["Real-time monitoring", "Stage conversion tracking", "Alert system"],
    complexity: "Moderate",
    timeEstimate: "10 min",
    icon: ChartBarIcon,
    isLive: false,
    demoUrl: "#"
  },
  {
    id: 6,
    name: "Competitive Intel Agent",
    category: "AI Agents",
    description: "Monitor competitors and generate battlecards with positioning and win strategies.",
    features: ["Competitive monitoring", "Battlecard generation", "Win strategy recommendations"],
    complexity: "Moderate",
    timeEstimate: "15-20 min",
    icon: UserGroupIcon,
    isLive: false,
    demoUrl: "#"
  }
]

const categories = [
  { name: "All Tools", value: "all" },
  { name: "AI Agents", value: "AI Agents" },
  { name: "Analytics", value: "Analytics" },
  { name: "Automation", value: "Automation" },
  { name: "Sales", value: "Sales" },
  { name: "Integrations", value: "Integrations" }
]

export default function ToolLibrarySection() {
  const [activeCategory, setActiveCategory] = useState('all')
  const [selectedTool, setSelectedTool] = useState<number | null>(null)

  const filteredTools = activeCategory === 'all' 
    ? featuredTools 
    : featuredTools.filter(tool => tool.category === activeCategory)

  return (
    <section id="tools" className="py-20 bg-bg-surface">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-h2 leading-tight mb-6 max-w-4xl mx-auto">
            Interactive AI Tools & Agent Library
          </h2>
          <p className="text-xl text-text-secondary leading-relaxed max-w-3xl mx-auto mb-8">
            Explore our comprehensive collection of {featuredTools.length}+ production-ready AI tools and agents. 
            Each tool demonstrates real-world applications with measurable business impact.
          </p>
          
          {/* Live Demo Highlight */}
          <div className="inline-flex items-center space-x-2 bg-success-500/20 border border-success-500/30 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-success-500 rounded-full animate-pulse" />
            <span className="text-success-500 text-sm font-medium">
              Live Demo Available: Business Calculator Pro
            </span>
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category.value}
              onClick={() => setActiveCategory(category.value)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                activeCategory === category.value
                  ? 'bg-primary-500 text-black'
                  : 'bg-bg-page text-text-secondary hover:text-primary-500 hover:bg-primary-500/10'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {filteredTools.map((tool) => (
            <div key={tool.id} className="card group cursor-pointer">
              {/* Tool Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-lg bg-primary-500/20 flex items-center justify-center group-hover:bg-primary-500/30 transition-colors duration-200">
                    <tool.icon className="h-6 w-6 text-primary-500" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-primary-500 text-xs font-medium">{tool.category}</span>
                      {tool.isLive && (
                        <span className="bg-success-500/20 text-success-500 text-xs px-2 py-1 rounded-full">
                          Live
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-xs text-text-secondary">{tool.complexity}</div>
                  <div className="text-xs text-primary-500 font-mono">{tool.timeEstimate}</div>
                </div>
              </div>

              {/* Tool Name */}
              <h3 className="font-heading font-semibold text-h4 text-text-primary mb-3 group-hover:text-primary-500 transition-colors duration-200">
                {tool.name}
              </h3>

              {/* Tool Description */}
              <p className="text-text-secondary text-sm leading-relaxed mb-4">
                {tool.description}
              </p>

              {/* Features List */}
              <div className="space-y-2 mb-6">
                {tool.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-500 rounded-full flex-shrink-0" />
                    <span className="text-text-secondary text-xs">{feature}</span>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-2">
                {tool.isLive ? (
                  <a
                    href={tool.demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary flex-1 text-sm flex items-center justify-center space-x-2"
                  >
                    <PlayCircleIcon className="h-4 w-4" />
                    <span>Launch Tool</span>
                  </a>
                ) : (
                  <button
                    onClick={() => setSelectedTool(tool.id)}
                    className="btn-secondary flex-1 text-sm flex items-center justify-center space-x-2"
                  >
                    <PlayCircleIcon className="h-4 w-4" />
                    <span>View Demo</span>
                  </button>
                )}
                
                <button className="btn-ghost px-4">
                  <ArrowTopRightOnSquareIcon className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Tool Library Stats */}
        <div className="bg-bg-page rounded-lg p-8 border border-border-subtle">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">35+</div>
              <div className="text-text-secondary text-sm">AI Tools Available</div>
            </div>
            <div>
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">12</div>
              <div className="text-text-secondary text-sm">Live Demonstrations</div>
            </div>
            <div>
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">5</div>
              <div className="text-text-secondary text-sm">Industries Covered</div>
            </div>
            <div>
              <div className="text-3xl font-mono font-bold text-primary-500 mb-2">85%</div>
              <div className="text-text-secondary text-sm">Average Accuracy Rate</div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <h3 className="font-heading font-semibold text-h3 mb-4">
            Ready to Experience Our AI Tools?
          </h3>
          <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
            Book a personalized demonstration and see how our AI agents can transform your operations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#calculator" className="btn-primary">
              Try Live Calculator
            </a>
            <a href="#contact" className="btn-secondary">
              Schedule Demo
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}