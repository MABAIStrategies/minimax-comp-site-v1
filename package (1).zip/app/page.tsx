'use client'

import { useState, useEffect } from 'react'
import HeroSection from '@/components/HeroSection'
import ProblemSolutionSection from '@/components/ProblemSolutionSection'
import ToolLibrarySection from '@/components/ToolLibrarySection'
import IndustryFocusSection from '@/components/IndustryFocusSection'
import MABDifferenceSection from '@/components/MABDifferenceSection'
import SocialProofSection from '@/components/SocialProofSection'
import AboutSection from '@/components/AboutSection'
import CalculatorSection from '@/components/CalculatorSection'
import CTASection from '@/components/CTASection'

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <div className={`transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
      <HeroSection />
      <ProblemSolutionSection />
      <ToolLibrarySection />
      <IndustryFocusSection />
      <MABDifferenceSection />
      <SocialProofSection />
      <CalculatorSection />
      <AboutSection />
      <CTASection />
    </div>
  )
}