import './globals.css'
import type { Metadata } from 'next'
import { Inter, Satoshi } from 'next/font/google'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap'
})

const satoshi = Satoshi({
  subsets: ['latin'],
  variable: '--font-satoshi',
  display: 'swap'
})

export const metadata: Metadata = {
  title: 'MAB AI Strategies - Transform Healthcare & Telecom Operations with Enterprise AI Automation',
  description: 'We build custom AI agents, intelligent workflows, and automation systems that deliver measurable ROI – backed by $12M+ in proven B2B revenue impact.',
  keywords: ['AI automation', 'healthcare AI', 'telecom AI', 'custom AI agents', 'process automation', 'enterprise AI solutions'],
  authors: [{ name: 'Mark Bockrath' }],
  creator: 'MAB AI Strategies LLC',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://mabaistrategies.com',
    siteName: 'MAB AI Strategies',
    title: 'MAB AI Strategies - Enterprise AI Automation',
    description: 'Transform your healthcare and telecom operations with custom AI agents and automation systems.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'MAB AI Strategies - Enterprise AI Automation',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MAB AI Strategies - Enterprise AI Automation',
    description: 'Transform your healthcare and telecom operations with custom AI agents and automation systems.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${satoshi.variable} dark`}>
      <body className="font-body antialiased">
        <Navigation />
        <main className="min-h-screen">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  )
}